package ch02;

public class ObjectLingkaran {
    public static void main(String[]args){
        Lingkaran x = new Lingkaran ();
        x.jariJari = 15;
        System.out.println("Luas Lingkaran ="+x.luas ());
    }
}