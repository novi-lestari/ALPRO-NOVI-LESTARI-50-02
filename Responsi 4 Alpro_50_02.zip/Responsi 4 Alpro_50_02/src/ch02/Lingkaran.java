package ch02;

public class Lingkaran {
    double jariJari;
    double luas() {
        return Math.PI * jariJari * jariJari;
    }
}