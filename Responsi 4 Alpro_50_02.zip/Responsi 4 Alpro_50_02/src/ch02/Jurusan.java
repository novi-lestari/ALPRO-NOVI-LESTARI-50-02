package ch02;

public class Jurusan {
    String nama;
    int jumlahMahasiswa;
    String akreditasi;

    public String getNama() {
        return nama;
    }
    public int getJumlahMahasiswa() {
        return jumlahMahasiswa;
    }
    public String getAkreditasi () {
        return akreditasi;
    }
}