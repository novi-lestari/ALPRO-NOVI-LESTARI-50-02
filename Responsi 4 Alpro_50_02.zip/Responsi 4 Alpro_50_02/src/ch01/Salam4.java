package ch01;

public class Salam4 {
    public static void main(String[]args){
        String nama = "Budi";
        System.out.println("Hai "+ nama);
    }
}