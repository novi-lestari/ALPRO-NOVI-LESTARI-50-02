package ch01;

public class Salam5{
    public static void main(String[]args){
        String nama = "Citra";
        String kalimat = "Hai " + nama;
        System.out.println(kalimat);
    }
}