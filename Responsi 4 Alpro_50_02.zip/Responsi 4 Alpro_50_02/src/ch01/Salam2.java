package ch01;

public class Salam2 {
    public static void main(String[]args){
        System.out.println("Salam Budi!");
        System.out.println("Salam Citra");
    }
}