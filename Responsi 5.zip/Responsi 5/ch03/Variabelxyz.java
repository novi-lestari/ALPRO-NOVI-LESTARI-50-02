package ch03;

public class Variabelxyz {
	public static void main(String[] args){
		
		int	x = 10;
		int y = 30;
		int z = 20;
		if (x > z) {
			System.out.println("nilai tertingginya adalah = " + x);
		}
		if (y > x){
			System.out.println("nilai tertingginya adalah = " + y);
		} if (y < z){
			System.out.println("nilai tertingginya adalah = " + z);
		}
	}
}