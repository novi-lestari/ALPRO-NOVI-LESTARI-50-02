package ch03;

public class Variabelxy {
	public static void main(String[] args) {
		int x = 100;
		int y = 50;
		if(x > y){
			System.out.println("nilai tertinggi " + x);
		} else {
			System.out.println("nilai tertinggi " + y);
		}
	}
}